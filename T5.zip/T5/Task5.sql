/* =====================================================================
   TASK 5: SQL JOINS (INNER, LEFT, RIGHT, FULL)
   =====================================================================
   Objective   : Learn to combine data from multiple tables
   Tools       : DB Browser for SQLite / MySQL Workbench
   Deliverables: SQL queries using all join types
   Key Concepts: Joins, Relationships, Multi-table Merging
   ===================================================================== */

-- ---------------------------------------------------------------------
-- STEP 1: SCHEMA SETUP (Customers, Orders, Payments, Employees)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS task5_payments;
DROP TABLE IF EXISTS task5_orders;
DROP TABLE IF EXISTS task5_customers;
DROP TABLE IF EXISTS task5_employees;

CREATE TABLE task5_customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    city VARCHAR(50)
);

CREATE TABLE task5_orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    CONSTRAINT fk_t5_customer FOREIGN KEY (customer_id) 
        REFERENCES task5_customers(customer_id)
);

CREATE TABLE task5_payments (
    payment_id INT PRIMARY KEY,
    order_id INT,
    payment_method VARCHAR(50) NOT NULL,
    payment_status VARCHAR(50) NOT NULL
);

-- Separate table to demonstrate Self-Joins
CREATE TABLE task5_employees (
    emp_id INT PRIMARY KEY,
    emp_name VARCHAR(100) NOT NULL,
    manager_id INT
);

-- ---------------------------------------------------------------------
-- STEP 2: INSERT SAMPLE DATA
-- (Includes customers with no orders, and an order with no customer)
-- ---------------------------------------------------------------------
INSERT INTO task5_customers (customer_id, customer_name, city) VALUES
(1, 'Alice Smith', 'Delhi'),
(2, 'Bob Johnson', 'Mumbai'),
(3, 'Charlie Brown', 'Bengaluru'),
(4, 'Diana Prince', 'Hyderabad'); -- Has no orders

INSERT INTO task5_orders (order_id, customer_id, order_date, total_amount) VALUES
(101, 1, '2026-01-15', 1200.00),
(102, 1, '2026-02-10', 450.00),
(103, 2, '2026-02-18', 3200.00),
(104, NULL, '2026-03-01', 890.00); -- Guest checkout (no customer_id)

INSERT INTO task5_payments (payment_id, order_id, payment_method, payment_status) VALUES
(501, 101, 'Credit Card', 'Completed'),
(502, 102, 'UPI', 'Completed'),
(503, 103, 'Net Banking', 'Completed');

INSERT INTO task5_employees (emp_id, emp_name, manager_id) VALUES
(1, 'Kavita Iyer', NULL),       -- CEO / Top Manager
(2, 'Arun Verma', 1),           -- Reports to Kavita
(3, 'Sneha Patel', 1),          -- Reports to Kavita
(4, 'Vikram Das', 2);           -- Reports to Arun


-- =====================================================================
-- STEP 3: JOIN DEMONSTRATIONS
-- =====================================================================

-- 1. INNER JOIN
-- Returns only rows with matching customer_id in BOTH tables.
SELECT 
    c.customer_id,
    c.customer_name,
    o.order_id,
    o.order_date,
    o.total_amount
FROM task5_customers c
INNER JOIN task5_orders o
    ON c.customer_id = o.customer_id;


-- 2. LEFT JOIN (LEFT OUTER JOIN)
-- Returns all customers, plus their order details if any exist.
-- If a customer has no orders, order fields display as NULL.
SELECT 
    c.customer_id,
    c.customer_name,
    c.city,
    o.order_id,
    o.total_amount
FROM task5_customers c
LEFT JOIN task5_orders o
    ON c.customer_id = o.customer_id;


-- 3. RIGHT JOIN (RIGHT OUTER JOIN)
-- Returns all orders, plus customer details if available.
-- Order 104 has customer_id = NULL, so customer fields display as NULL.
SELECT 
    c.customer_name,
    o.order_id,
    o.order_date,
    o.total_amount
FROM task5_customers c
RIGHT JOIN task5_orders o
    ON c.customer_id = o.customer_id;


-- 4. FULL OUTER JOIN
-- Returns all customers and all orders.
-- Note: MySQL and SQLite do not natively support FULL OUTER JOIN syntax.
-- Standard ANSI implementation via UNION of LEFT JOIN and RIGHT JOIN:
SELECT 
    c.customer_id,
    c.customer_name,
    o.order_id,
    o.total_amount
FROM task5_customers c
LEFT JOIN task5_orders o
    ON c.customer_id = o.customer_id
UNION
SELECT 
    c.customer_id,
    c.customer_name,
    o.order_id,
    o.total_amount
FROM task5_customers c
RIGHT JOIN task5_orders o
    ON c.customer_id = o.customer_id;


-- 5. JOINING MORE THAN 2 TABLES (Three-Table Join)
-- Connect Customers -> Orders -> Payments
SELECT 
    c.customer_name,
    o.order_id,
    o.total_amount,
    p.payment_method,
    p.payment_status
FROM task5_customers c
INNER JOIN task5_orders o
    ON c.customer_id = o.customer_id
INNER JOIN task5_payments p
    ON o.order_id = p.order_id;


-- 6. SELF-JOIN
-- A table joined with itself to model hierarchy (Employees and their Managers).
SELECT 
    e.emp_name AS employee,
    COALESCE(m.emp_name, 'Top Level Management') AS reports_to
FROM task5_employees e
LEFT JOIN task5_employees m
    ON e.manager_id = m.emp_id;


-- 7. CROSS JOIN (Cartesian Product)
-- Pairs every single row of Table A with every single row of Table B.
SELECT 
    c.customer_name,
    o.order_id
FROM task5_customers c
CROSS JOIN task5_orders o;


-- 8. NATURAL JOIN
-- Joins automatically on all columns with identical names across both tables.
SELECT 
    customer_id,
    customer_name,
    order_id,
    total_amount
FROM task5_customers
NATURAL JOIN task5_orders;


-- 9. JOIN WITHOUT A FOREIGN KEY
-- Any two tables can be joined on compatible data types without an explicit FK constraint.
SELECT 
    o.order_id,
    o.total_amount,
    p.payment_method
FROM task5_orders o
INNER JOIN task5_payments p
    ON o.order_id = p.order_id;